public class Vendedor {
    
}
